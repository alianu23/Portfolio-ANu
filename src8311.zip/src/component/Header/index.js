import React from "react";
import { BsFillSunFill, BsFillMoonFill } from "react-icons/bs";
import styles from "./style.module.css";
import Link from "next/link";
import { CssVarsProvider, useColorScheme } from "@mui/joy/styles";

import Button from "@mui/joy/Button";

function ModeToggle() {
  const { mode, setMode } = useColorScheme();
  const [mounted, setMounted] = React.useState(false);

  // necessary for server-side rendering
  // because mode is undefined on the server
  React.useEffect(() => {
    setMounted(true);
  }, []);
  if (!mounted) {
    return null;
  }

  return (
    <Button
      variant="soft"
      color="neutral"
      onClick={() => {
        setMode(mode === "light" ? "dark" : "light");
      }}
    >
      {mode === "light" ? "Turn dark" : "Turn light"}
    </Button>
  );
}

function Header() {
  return (
    <CssVarsProvider>
      <header className={styles.header}>
        <Link href="./HomePage">
          <h1 className={styles.portfolio}>Portfolio</h1>{" "}
          <p style={{ width: 45, height: 2, backgroundColor: "black" }}> </p>
        </Link>
        <div style={{ width: 60 }}>
          <ModeToggle />
        </div>
        <div className={styles.bigcontain}>
          <div className={styles.inside}>
            <Link className={styles.headerP} href="./HomePage">
              Home
            </Link>
            <Link className={styles.headerP} href="./Aboutpage">
              About
            </Link>
            <Link className={styles.headerP} href="./Projects">
              Projects
            </Link>
            <Link className={styles.hbutton} href="./Contact">
              Contact
            </Link>
          </div>
        </div>
      </header>
    </CssVarsProvider>
  );
}

export default Header;
