import React from "react";
import { Projectd } from "@/data";
import { ProjectData } from "./ProjectData";

export default function Project() {
  return (
    <>
      <div
        style={{
          display: "flex",
          flexDirection: "column",
          justifyContent: "center",
          alignItems: "center",
        }}
      >
        <h1 style={{ fontSize: 48 }}>PROJECT</h1>
        <div style={{ width: 40, height: 3, backgroundColor: "black" }}></div>
      </div>
      <div style={{ display: "flex" }}>
        {Projectd.map((el) => (
          <ProjectData data={el} key={el.id} />
        ))}
      </div>
    </>
  );
}
