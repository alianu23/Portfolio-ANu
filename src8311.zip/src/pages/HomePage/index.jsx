import React from "react";
import styles from "./style.module.css";
import Button from "@/component/Buttons";
import Footer from "@/component/Footer";
import img from "@/data/zurag.png";
import { Typewriter } from "react-simple-typewriter";
function Home() {
  return (
    <>
      <div className={styles.contain}>
        <section className={styles.Intro}>
          <h3 style={{ fontSize: 32, color: "silver" }}>Hello</h3>
          <h1 className={styles.myName}>My name is Anudari Oyunbat</h1>
          <div className={styles.rrr}>
            <div style={{ display: "flex" }}>
              <h4 className={styles.about}>I'm </h4>
              <h4 className={styles.maj}>
                <Typewriter
                  words={[
                    "a UI/UX Designer",
                    "a Backend developer",
                    "a Frontend developer",
                    "a Full stack developer",
                  ]}
                  loop={1}
                  cursor
                  cursorStyle="|"
                  typeSpeed={70}
                  deleteSpeed={50}
                  delaySpeed={1000}
                />
              </h4>
            </div>
            <Footer />
            <Button />
          </div>
        </section>
        <img style={{ width: 650, Height: 500 }} src={img.src} alt="" />
      </div>
    </>
  );
}

export default Home;
